export interface Icustomers {

    id:number;
    CName:string;
    CAddr:string;
    email:string;
    telephone:string;
    fax:string;
    holding:string;
    authPerson:string;
    designation:string;
    gstNo:string;
    panNo:string;
    username:string;
    password:string;


}
