import { TestBed } from '@angular/core/testing';

import { AlternateService } from './alternate.service';

describe('AlternateService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AlternateService = TestBed.get(AlternateService);
    expect(service).toBeTruthy();
  });
});
