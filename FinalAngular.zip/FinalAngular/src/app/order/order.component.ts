import { Component, OnInit } from '@angular/core';
import { Imodel } from '../imodel';
import { SegmentService } from '../segment.service';
import { Imanufacturer } from '../imanufacturer';
import { RegService } from '../reg.service';
import { Icustomers } from '../icustomers';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  modelObj : Imodel;
  customerId : number;
  modelId : number;
  totalPrice : number;
  singleUnitPrice : number;
  manId : number;
  manu : Imanufacturer[];
  manObj : Imanufacturer;
  segId : number;
  minQty : number;
  customers : Icustomers[];
  customer : Icustomers;

  constructor(private segserv : SegmentService, private regServe : RegService) { 
    this.modelId = parseInt(localStorage.getItem('modelId'));
    this.segId = parseInt(localStorage.getItem('segmentId'));
    this.manId = parseInt(localStorage.getItem('manufactureId'));
    this.segserv.getModelById(this.modelId).subscribe(
      data =>
      {
        this.modelObj = data;
        // console.log("Hello") 
        // console.log(localStorage.getItem('singleUnitPrice'));     
      }
    )
    this.segserv.getManufacturer(this.segId).subscribe(
      data =>
      {
        this.manu = data;
        this.manu.forEach(element => {
          if(this.manId === element.id)
          {
            this.manObj = element;
            console.log(this.manObj);
          }
        });
      }
    )
    this.minQty = parseInt(localStorage.getItem('qty'));

    this.regServe.getCustomers().subscribe(
      data =>
      {
        this.customers = data;
        console.log(this.customers)
        let user = localStorage.getItem('user');
        console.log(user)
        this.customers.forEach(element => {
        if(element.username ==user)
        {
          this.customer = element;
        }
    });
      }
    )

  }

  ngOnInit() {
    // qty singleUnitPrice
    let qty = parseInt(localStorage.getItem('qty'));
    let sUP = parseFloat(localStorage.getItem('singleUnitPrice'));

    this.totalPrice = qty * sUP;
  }

  confirmOrder()
  {
    
  }

}
