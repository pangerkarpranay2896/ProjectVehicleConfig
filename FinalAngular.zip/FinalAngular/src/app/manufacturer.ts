import { Imanufacturer } from './imanufacturer';
import { Model } from './model';

export class Manufacturer implements Imanufacturer {
    constructor (public id : number, public manuName : string,
        public modelses : Set<Model>){}
}

