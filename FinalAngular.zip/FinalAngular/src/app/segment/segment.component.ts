import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, Form } from '@angular/forms';
import { SegmentService } from '../segment.service';
import { Isegment } from '../isegment';
import { Imanufacturer } from '../imanufacturer';
import { Imodel } from '../imodel';
import { Router } from '@angular/router';
import { RegService } from '../reg.service';

@Component({
  selector: 'app-segment',
  templateUrl: './segment.component.html',
  styleUrls: ['./segment.component.css']
})
export class SegmentComponent implements OnInit {

  segForm:FormGroup;
  segment:Isegment;
  manufacturers:Imanufacturer[];
  model:Imodel[];
  segId:number;
  min_qtyO :number;
  seg:Isegment[];
  flag : string;
  flagBool : boolean = true;


  constructor(public fb:FormBuilder,private segService:SegmentService ,private regService: RegService,private router:Router) { }

  ngOnInit() {
    //this.regService.islogined().subscribe(data => {this.flag = data; console.log(data+" session")});
    //console.log(this.flag.toString() === "false");
    console.log(localStorage.getItem('user'))
    if(localStorage.getItem('loginFlag')!="true")
    {
      this.router.navigate(['/login']);
      localStorage.setItem('loginError',"Please Login")
    }
    
    this.buildSegForm();
    this.segService.getSegment().subscribe(
    data => this.seg = data
   );
   //console.log(this.seg);
  }

  buildSegForm()
  {
    this.segForm = this.fb.group({
      segment: ['', [Validators.required]],
      manufacturer: ['', [Validators.required]],
      model: ['', [Validators.required]],
      quantity: []
    });
  }

  validate()
  {

  }



  onSubmit(segForm:FormGroup)
  {
    if(!segForm.valid)
    {
      console.log(segForm.value)
    }
    else{
      console.log(this.flagBool)
      if(this.flagBool)
      {
        this.router.navigate(['/defaultconfig']);
      }
      else
      {
      }
      
    }
    
  }


  onChangeSegment(segmId)
  {
    localStorage.setItem('segmentId',segmId);
    this.segId = parseInt(segmId);
    for(var segObj of this.seg)
    {
      if(segObj.id === this.segId)
      {
        this.segment = segObj;
        break;
      }
    }
    this.min_qtyO = this.segment.minQty;
    this.segService.getManufacturer(this.segment.id).subscribe(
      data=> 
      {
        this.manufacturers = data
        console.log(this.manufacturers);
      }
      
    );

  }

  // getById(segId : number) : Isegment
  // {
    
  // }

  onChangeManufact(manufact_id)
  {
    localStorage.setItem('manufactureId',manufact_id);
    var segment_id = this.segment.id;
    manufact_id = parseInt(manufact_id);
    this.segService.getModel(segment_id,manufact_id).subscribe(data=>this.model=data);
  }

  onChangeModel(model_id)
  {
    localStorage.setItem('modelId',model_id);
  }

  onChangeMaxQty(minQty)
  {
    localStorage.setItem('qty',minQty);
    minQty = parseInt(minQty)
    //console.log(minQty >= this.segment.minQty );
    if(minQty >= this.segment.minQty )
    {
      this.flagBool = true;
    }
    else
    {
      this.flagBool = false;
    }
  }


}
