import { Component, OnInit } from '@angular/core';
import { RegService } from '../reg.service';
import { routerNgProbeToken } from '@angular/router/src/router_module';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  errorMsg : string;
  onOff : string;
  user : string;
  constructor(private regService : RegService, private router : Router) {
    this.onOff = localStorage.getItem('loginFlag');
    console.log(this.onOff)
    if(this.onOff)
    {
      this.user = localStorage.getItem('user').toLocaleUpperCase();
    }
  }

  ngOnInit() {
  }

  logout()
  {
     localStorage.clear();
     this.user = "";
     this.router.navigate(['/login']);
  }


}
