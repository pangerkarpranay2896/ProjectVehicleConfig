import { Segment } from './segment';

describe('Segment', () => {
  it('should create an instance', () => {
    expect(new Segment()).toBeTruthy();
  });
});
