import { Iitems } from './iitems';

export interface Imodeldetail {
    id : number;
	model_id : number;
	item_id : number;
	model_type : string;
	model_config : string;
	config_type : string;
	alternateItem? : Iitems[];
	// models : number;
	// items : number;
	// modelType : string;
	// modelConfig : string;

}

