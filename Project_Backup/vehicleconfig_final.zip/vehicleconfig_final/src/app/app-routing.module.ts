import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {RegistrationComponent} from './registration/registration.component'
import { LoginComponent } from './login/login.component';
import { SegmentComponent } from './segment/segment.component';
import { DefaultConfigComponent } from './default-config/default-config.component';
import { ConfigurationComponent } from './configuration/configuration.component';
import { HomeComponent } from './home/home.component';
import { OrderComponent } from './order/order.component';



const routes: Routes = [

{ path:'registration',component: RegistrationComponent},
{ path:'login',component:LoginComponent},
{ path: 'segment',component:SegmentComponent},
{ path:'defaultconfig', component:DefaultConfigComponent},
{ path: 'configuration', component:ConfigurationComponent},
{ path: 'home', component:HomeComponent},
{ path: 'order', component:OrderComponent},
{ path: '', component:HomeComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
