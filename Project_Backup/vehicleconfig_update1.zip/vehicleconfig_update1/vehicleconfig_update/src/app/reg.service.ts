import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RegService 
{

  url="http://localhost:8080/ManufacturerService";
  constructor(private http: HttpClient) { }


  postcustomer(cusObj):Observable<any>
  {
    return this.http.post<any>(this.url+"/crud/addCustomer",cusObj);
  }


  logincustomer(cusObj):Observable<any>
  {
    return this.http.post<any>(this.url+"/crud/login",cusObj);
  }

  // islogined():Observable<any>
  // {
  //   return this.http.get<any>(this.url+"/crud/loginedOrNot");
  // }

  // invalidate():Observable<any>
  // {
  //   return this.http.get<any>(this.url+"/crud/logout");
  // }

  getCustomers(): Observable<any>
  {
    return this.http.get<any>(this.url+"/crud/customers");
  }


}
