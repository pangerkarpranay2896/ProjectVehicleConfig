import { Imodeldetail } from './imodeldetail';

export class Modeldetail implements Imodeldetail {
    constructor (
    public id : number,
	public model_id : number,
	public item_id : number,
	public model_type : string,
	public model_config : string,
	public config_type : string
    ){}
}
