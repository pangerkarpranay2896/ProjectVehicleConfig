import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AlternateService {

  url = "http://localhost:8080/ManufacturerService/";

  constructor(private http : HttpClient) { }

  getModelDetails(modelId : number, modelType : string) : Observable<any>
  {
    return this.http.get<any>(this.url+"crud/getModelDetailsByModelId/"+modelId+"/"+modelType);
  }

  getAlternateItems(model_id: number) : Observable<any>
  {
    return this.http.get<any>(this.url+"crud/getAlternateItems/"+model_id);
  }

  getPrice(alt_tbl_id : number, model_id : number): Observable<any>
  {
    return this.http.get<any>(this.url+"crud/getPriceDemo/"+alt_tbl_id+"/"+model_id);
  }

}
