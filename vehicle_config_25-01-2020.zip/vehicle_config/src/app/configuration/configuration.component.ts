import { Component, OnInit } from '@angular/core';
import { Iitems } from '../iitems';
import { Imodel } from '../imodel';
import { DefaultServService } from '../default-serv.service';
import { Router } from '@angular/router';
import { SegmentService } from '../segment.service';
import { Imodeldetail } from '../imodeldetail';
import { AlternateService } from '../alternate.service';


@Component({
  selector: 'app-configuration',
  templateUrl: './configuration.component.html',
  styleUrls: ['./configuration.component.css']
})
export class ConfigurationComponent implements OnInit {

  defaultFeatures:Iitems[];
  interiorFeatures:Iitems[];
  exteriorFeatures:Iitems[];
  standredFeatures:Iitems[];

  modelDetail : Imodeldetail[];
  alternateItem : Iitems[];
  


  modelObj : Imodel;
  image : string;
  flag : boolean = false;
  modelId : number;

  constructor(private alternateService : AlternateService, private router:Router) 
  { 
        
  }

  ngOnInit() {

    if(localStorage.getItem('loginFlag')!="true")
    {
      this.router.navigate(['/login']);
      localStorage.setItem('loginError',"Please Login")
    }
    else{
      this.modelId = parseInt(localStorage.getItem('modelId'));
      this.alternateService.getModelDetails(2,'Interior').subscribe(
        (data) =>
        {
            this.modelDetail = data;
            this.modelDetail.forEach(elementmd => {
              this.alternateService.getAlternateItems(elementmd.item_id).subscribe(
                data =>
                {
                  var i = 0;
                  this.alternateItem = data;
                  
                  this.alternateItem.forEach(element => {
                      this.alternateService.getPrice(element.id).subscribe(
                        data =>
                        {
                          element.deltaPrice = parseInt(data);
                          i++;
                        }
                      )
                  });
                  console.log(this.alternateItem);

                }
              )
            });
             console.log(this.modelDetail);
        }
      );
    }
    
    
  }

 

}
