export interface Ialttbl {
    
}
