import { Icustomers } from './icustomers';

export class Customers implements Icustomers{

    constructor(public id:number,public CName:string,public CAddr:string,public email:string,public telephone:string,public fax:string,
        public holding:string,public authPerson:string,public designation:string,public panNo:string,public gstNo:string,
        public username:string,public password:string)
    {
    
    }
}
