import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {RegistrationComponent} from './registration/registration.component'
import { LoginComponent } from './login/login.component';
import { SegmentComponent } from './segment/segment.component';
import { DefaultConfigComponent } from './default-config/default-config.component';
import { ConfigurationComponent } from './configuration/configuration.component';



const routes: Routes = [

{ path:'registration',component: RegistrationComponent},
{ path:'login',component:LoginComponent},
{ path: 'segment',component:SegmentComponent},
{ path:'defaultconfig', component:DefaultConfigComponent},
{ path: 'configuration', component:ConfigurationComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
