import { Component, OnInit } from '@angular/core';
import { DefaultServService } from '../default-serv.service';
import { Router } from '@angular/router';
import { Iitems } from '../iitems';
import { Imodel } from '../imodel';
import { SegmentService } from '../segment.service';


@Component({
  selector: 'app-default-config',
  templateUrl: './default-config.component.html',
  styleUrls: ['./default-config.component.css']
})
export class DefaultConfigComponent implements OnInit {

  defaultFeatures:Iitems[];
  interiorFeatures:Iitems[];
  exteriorFeatures:Iitems[];
  standredFeatures:Iitems[];
  modelObj : Imodel;
  image : string;
  flag : boolean = false;
  modelId : number;

  constructor(private defaultService:DefaultServService,private router:Router, private segserve : SegmentService ) 
  { 
    if(localStorage.getItem('loginFlag')!="true")
    {
      this.router.navigate(['/login']);
      localStorage.setItem('loginError',"Please Login")
    }
    else{
      this.modelId = parseInt(localStorage.getItem('modelId'));
      console.log(this.modelId);
      this.segserve.getModelById(this.modelId).subscribe(
        data => {this.modelObj = data; console.log(this.modelObj); this.flag = true;}
      );
    }
    
  }

  ngOnInit() {

    // while(this.modelObj == undefined)
    // {
    // }
    //this.image = "abcd";
    //this.image = this.modelObj.modelImg;
    // this.defaultFeatures= this.defaultService.getDefaultFeatures();
    // this.interiorFeatures=this.defaultService.getInteriorFeatures();
    // this.exteriorFeatures=this.defaultService.getExteriorFeatures();
    // this.standredFeatures=this.defaultService.getStandredFeatures();


      this.defaultService.getDefaultFeatures(this.modelId).subscribe(data=>this.defaultFeatures=data);
      this.defaultService.getInteriorFeatures(this.modelId).subscribe(data=>this.interiorFeatures=data);
      this.defaultService.getExteriorFeatures(this.modelId).subscribe(data=>this.exteriorFeatures=data);
      //this.defaultService.getStandredFeatures(2).subscribe(data1=>this.standredFeatures=data1);
    }

}
