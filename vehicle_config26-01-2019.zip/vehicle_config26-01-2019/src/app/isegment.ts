import { Model } from './model';

export interface Isegment {
    id : number;
    segType : string;
    minQty : number;
    modelses  : Set<Model>;
}
