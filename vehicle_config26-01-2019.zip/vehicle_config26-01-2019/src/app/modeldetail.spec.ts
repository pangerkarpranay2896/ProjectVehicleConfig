import { Modeldetail } from './modeldetail';

describe('Modeldetail', () => {
  it('should create an instance', () => {
    expect(new Modeldetail()).toBeTruthy();
  });
});
