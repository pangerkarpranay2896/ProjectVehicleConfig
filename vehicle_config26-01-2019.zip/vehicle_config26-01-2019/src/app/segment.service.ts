import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Isegment } from './isegment';
import { Imodel } from './imodel';
import { Imanufacturer } from './imanufacturer';

@Injectable({
  providedIn: 'root'
})
export class SegmentService {

  url='http://localhost:8080/ManufacturerService/';
  constructor(private http:HttpClient) { }

  getSegment():Observable<Isegment[]>
  {
    return this.http.get<Isegment[]>(this.url+"crud/segments");
  }

  getManufacturer(seg_id):Observable<Imanufacturer[]>
  {
    seg_id = parseInt(seg_id);
    //return this.http.get<Imanufacturer[]>(`${this.url}Customers/${seg_id}`);
    return this.http.get<Imanufacturer[]>(this.url+"crud/getManuBySegment/"+seg_id);
  }

  getModel(manu_id:number,seg_id:number):Observable<any>
  {
    //return this.http.get<Imodel>(`${this.url}Select/?mid=${manu_id}&sid=${seg_id}`);
    return this.http.get<Imanufacturer[]>(this.url+"crud/getModelBySegment/"+seg_id+"/"+manu_id);
  }

  //
  getModelById(id : number):Observable<any>
  {
      return this.http.get<Imodel>(this.url+"crud/getModelByid/"+id);
  }

  // getminQty(seg_id:number)
  // {
  //   return this.http.get<Isegment>('${this.url}');
  // }






}
