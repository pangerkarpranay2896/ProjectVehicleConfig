import { Isegment } from './isegment';
import { Model } from './model';

export class Segment implements Isegment {

    constructor(public id : number, public segType : string,
         public minQty : number, public modelses  : Set<Model>){}
}