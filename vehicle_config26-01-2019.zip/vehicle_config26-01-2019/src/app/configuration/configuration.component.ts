import { Component, OnInit } from '@angular/core';
import { Iitems } from '../iitems';
import { Imodel } from '../imodel';
import { DefaultServService } from '../default-serv.service';
import { Router } from '@angular/router';
import { SegmentService } from '../segment.service';
import { Imodeldetail } from '../imodeldetail';
import { AlternateService } from '../alternate.service';
import { CommonModule } from '@angular/common'
import { element } from 'protractor';

@Component({
  selector: 'app-configuration',
  templateUrl: './configuration.component.html',
  styleUrls: ['./configuration.component.css']
})
export class ConfigurationComponent implements OnInit {

  defaultFeatures:Iitems[];
  interiorFeatures:Iitems[];
  exteriorFeatures:Iitems[];
  standredFeatures:Iitems[];
  myMap : Map<string,number>;
  modelDetail : Imodeldetail[];
   
  //alternateItem : Iitems[];
  globalPrice : number;
  i : number = 0;
  temp : number=0;
  modelObj : Imodel;
  image : string;
  flag : boolean = false;
  modelId : number;
  currPrice : number = 0;                                  
  constructor(private alternateService : AlternateService, private router:Router, private segServ : SegmentService) 
  { 
    this.myMap = new Map();   
  }

  ngOnInit() {

    if(localStorage.getItem('loginFlag')!="true")
    {
      this.router.navigate(['/login']);
      localStorage.setItem('loginError',"Please Login")
    }
    else{
      this.modelId = parseInt(localStorage.getItem('modelId'));
      console.log(this.modelId+"Hello");
      this.segServ.getModelById(this.modelId).subscribe(
        data => {this.modelObj = data; console.log(this.modelObj); this.flag = true;}
      );
      this.segServ.getModelById(this.modelId).subscribe(
        data =>
        {
          this.modelObj = data;
          this.globalPrice = this.modelObj.price;
          this.currPrice = this.globalPrice; 
          this.alternateService.getModelDetails(this.modelObj.id,'Interior').subscribe(
            (data) =>
            {
                this.modelDetail = data;
                this.modelDetail.forEach(elementmd => {
                  this.alternateService.getAlternateItems(elementmd.item_id).subscribe(
                    data =>
                    {
                      elementmd.alternateItem = data;
                      elementmd.alternateItem.forEach(element => {
                          console.log(element.id);
                          this.alternateService.getPrice(element.id,this.modelObj.id).subscribe(
                            data =>
                            {
                              element.deltaPrice = parseFloat(data);
                            }
                          )
                      });    
                    }
                  )
                });
                console.log(this.modelDetail);
            }
          );
        }
      );
      
    } 
  }


  changePrice(obj)
  {
    this.currPrice = this.globalPrice;
    console.log(obj);
    let altItemId = parseFloat(obj);
    let key : string;
    let diff : number;
    this.modelDetail.forEach(element1 => {
      element1.alternateItem.forEach(element2 => {
       if( element2.id == altItemId)
       {
          diff = element2.deltaPrice;
          key = element1.config_type;
       }
      });
    });
    this.myMap.set(key,diff);
    this.currPrice = this.currPrice + this.dispdata(this.myMap);
  }
  dispdata(temp)
  {
    let sum : number =0;
    console.log(temp)
    temp.forEach((value: number , key: string) => {
      sum = sum + value;
    });
  return sum;
  }
 

}
