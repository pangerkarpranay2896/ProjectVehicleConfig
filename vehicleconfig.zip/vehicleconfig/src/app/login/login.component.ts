import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Icustomers } from '../icustomers';
import { Router } from '@angular/router';
import { Customers } from '../customers';
import { RegService } from '../reg.service';
import { stringify } from 'querystring';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit
 {
loginForm:FormGroup;
loginObj:Icustomers;
submitted=false;
  
  ngOnInit()
   {
     this.buildLoginForm();
  }

  constructor(public fb:FormBuilder,public dataserv:RegService,public router:Router) 
  { }

  buildLoginForm()
{
   this.loginForm=this.fb.group({
    
    username:['',[Validators.required]],
    password:['',[Validators.required]],
  

   });
}

get username()
{
  return this.loginForm.get('username');
}
get password()
{
  return this.loginForm.get('password');
}

onSubmit(empForm:FormGroup)
{
  this.submitted=true;
  if(!empForm.valid)
  {
    console.log(empForm.value);
  }
  this.mapFormValues(empForm);
  this.postData(this.loginObj);
}

mapFormValues(form:FormGroup)
{
  this.loginObj=new Customers(1,'c','c','c','c','c','c','c','c','c','c','c','c');
  this.loginObj.username=form.controls.username.value;
  this.loginObj.password=form.controls.password.value;
}
postData(loginObj)
{
  var booleanValue : string;
  this.dataserv.logincustomer(loginObj).subscribe
  (
    data=>
    {
      console.log(data);
      booleanValue = data;
      if(booleanValue==="true")
      {
        this.router.navigate(['/segment']);
      }
      else
      {
        this.router.navigate(['/home']);
      }
    }
  );
  // if(booleanValue==="true")
  // {
  //   this.router.navigate(['/segment']);
  // }
  // else
  // {
  //   this.router.navigate(['/home']);
  // }

}
}
