import { Component, OnInit } from '@angular/core';
import { DefaultServService } from '../default-serv.service';
import { Router } from '@angular/router';
import { Iitems } from '../iitems';

@Component({
  selector: 'app-default-config',
  templateUrl: './default-config.component.html',
  styleUrls: ['./default-config.component.css']
})
export class DefaultConfigComponent implements OnInit {

  defaultFeatures:Iitems[];
  interiorFeatures:Iitems[];
  exteriorFeatures:Iitems[];
  standredFeatures:Iitems[];


  constructor(private defaultService:DefaultServService,router:Router) { }

  ngOnInit() {

    this.defaultFeatures= this.defaultService.getDefaultFeatures();
    this.interiorFeatures=this.defaultService.getInteriorFeatures();
    this.exteriorFeatures=this.defaultService.getExteriorFeatures();
    this.standredFeatures=this.defaultService.getStandredFeatures();


      //  this.defaultService.getDefaultFeatures().subscribe(data=>this.defaultFeatures=data);
      //  this.defaultService.getInteriorFeatures().subscribe(data=>this.defaultFeatures=data);
      //  this.defaultService.getExteriorFeatures().subscribe(data=>this.exteriorFeatures=data);
      //  this.defaultService.getStandredFeatures().subscribe(data1=>this.standredFeatures=data1);

  }

}
