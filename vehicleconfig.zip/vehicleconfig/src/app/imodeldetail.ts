export interface Imodeldetail {
    id : number;
	models : number;
	items : number;
	modelType : string;
	modelConfig : string;
}

