import { Alttbl } from './alttbl';
import { Modeldetail } from './modeldetail';

export class Items  implements Items{
    constructor (public id : number, public name : string, public modelDetails : Set<Modeldetail>,
        public altTbls : Set<Alttbl>){};
}

