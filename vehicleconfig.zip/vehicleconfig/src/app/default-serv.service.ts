import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Iitems } from './iitems';
import { devModeEqual } from '@angular/core/src/change_detection/change_detection';

@Injectable({
  providedIn: 'root'
})
export class DefaultServService {

  url="";
  constructor(private http:HttpClient) { }





  getDefaultFeatures():Iitems[]
  {
    let drona=new Set([]);
    let roar=new Set([]);
      return [  
        {
          id: 1, 
          name:"demo",
          modelDetails:roar,
          altTbls: drona
     
        },
        {
          id: 2, 
          name:"demo1",
          modelDetails:roar,
          altTbls: drona
        }
  
      ]
  }


  getStandredFeatures():Iitems[]
  {
    let drona=new Set([]);
    let roar=new Set([]);
      return [  
        {
          id: 1, 
          name:"san",
          modelDetails:roar,
          altTbls: drona
     
        },
        {
          id: 2, 
          name:"san1",
          modelDetails:roar,
          altTbls: drona
        }
  
      ]
  }

  getExteriorFeatures():Iitems[]
  {
    let drona=new Set([]);
    let roar=new Set([]);
      return [  
        {
          id: 1, 
          name:"jan",
          modelDetails:roar,
          altTbls: drona
     
        },
        {
          id: 2, 
          name:"jan1",
          modelDetails:roar,
          altTbls: drona
        }
  
      ]
  }

  getInteriorFeatures():Iitems[]
  {
    let drona=new Set([]);
    let roar=new Set([]);
      return [  
        {
          id: 1, 
          name:"man",
          modelDetails:roar,
          altTbls: drona
     
        },
        {
          id: 2, 
          name:"man",
          modelDetails:roar,
          altTbls: drona
        }
  
      ]
  }

  // getDefaultFeatures():Observable<Iitems[]>
  // {
  //     return this.http.get<Iitems[]>(this.url+"");
  // }

  // getStandredFeatures():Observable<Iitems[]>
  // {
  //   return this.http.get<Iitems[]>(this.url+"");
  // }

  // getExteriorFeatures():Observable<Iitems[]>
  // {
  //   return this.http.get<Iitems[]>(this.url+"");
  // }
  
  // getInteriorFeatures():Observable<Iitems[]>
  // {
  //   return this.http.get<Iitems[]>(this.url+"");
  // }


}
