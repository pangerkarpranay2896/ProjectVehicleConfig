import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SegmentService } from '../segment.service';
import { Isegment } from '../isegment';
import { Imanufacturer } from '../imanufacturer';
import { Imodel } from '../imodel';
import { Router } from '@angular/router';

@Component({
  selector: 'app-segment',
  templateUrl: './segment.component.html',
  styleUrls: ['./segment.component.css']
})
export class SegmentComponent implements OnInit {

  segForm:FormGroup;
  segment:Isegment;
  manufacturers:Imanufacturer[];
  model:Imodel[];
  segId:number;
  min_qtyO :number;
  seg:Isegment[];




  constructor(public fb:FormBuilder,private segService:SegmentService ,private router:Router) { }

  ngOnInit() {
   this.buildSegForm();
   this.segService.getSegment().subscribe(
    data => this.seg = data
   );
   //console.log(this.seg);
  }

  buildSegForm()
  {
    this.segForm = this.fb.group({
      segment: ['', [Validators.required]],
      manufacturer: ['', Validators.required],
      model: ['', Validators.required],
      quantity: ['', Validators.required]
    });
  }



  onChangeSegment(segmId)
  {
    this.segId = parseInt(segmId);
    for(var segObj of this.seg)
    {
      if(segObj.id === this.segId)
      {
        this.segment = segObj;
        break;
      }
    }
    this.min_qtyO = this.segment.minQty;
    this.segService.getManufacturer(this.segment.id).subscribe(
      data=> this.manufacturers = data
    );

  }

  // getById(segId : number) : Isegment
  // {
    
  // }

  onChangeManufact(manufact_id)
  {
    var segment_id = this.segment.id;
    manufact_id = parseInt(manufact_id);
    this.segService.getModel(segment_id,manufact_id).subscribe(data=>this.model=data);
  }



}
