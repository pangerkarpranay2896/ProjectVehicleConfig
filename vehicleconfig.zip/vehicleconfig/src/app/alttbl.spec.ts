import { Alttbl } from './alttbl';

describe('Alttbl', () => {
  it('should create an instance', () => {
    expect(new Alttbl()).toBeTruthy();
  });
});
