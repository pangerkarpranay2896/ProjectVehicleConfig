export interface Ialttbl {
}
