import { Imodeldetail } from './imodeldetail';

export class Modeldetail implements Imodeldetail {
    constructor (public id : number, public models : number, public items : number,
        public modelType : string, public modelConfig : string){}
}
