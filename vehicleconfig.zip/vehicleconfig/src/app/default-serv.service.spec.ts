import { TestBed } from '@angular/core/testing';

import { DefaultServService } from './default-serv.service';

describe('DefaultServService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DefaultServService = TestBed.get(DefaultServService);
    expect(service).toBeTruthy();
  });
});
