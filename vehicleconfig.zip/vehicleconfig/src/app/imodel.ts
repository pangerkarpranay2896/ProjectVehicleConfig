import { Modeldetail } from './modeldetail';
import { Alttbl } from './alttbl';

export interface Imodel {
    id : number;
	manufacturer: number;
	segments : number;
	modelName : number;
	modelDescip : string;
	modelImg : string;
	mfgDate : string;
	price : number;
	altTbls : Set<Alttbl>;
    modelDetails : Set<Modeldetail>;
}
