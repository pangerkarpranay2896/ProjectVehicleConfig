import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder,Validators } from '@angular/forms';
import { Icustomers } from '../icustomers';
import { RegService } from '../reg.service';
import { Router } from '@angular/router';
import { CONTEXT_NAME } from '@angular/compiler/src/render3/view/util';
import { Customers } from '../customers';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  regForm:FormGroup;
  regObj:Icustomers;
  submited=false;

  ngOnInit() 
  {
this.buildRegForm()
  }

  constructor(public fb:FormBuilder,public dataserv:RegService,public router:Router ) { }
   buildRegForm()
    {
    
    this.regForm=this.fb.group({
    
      CName:['',[Validators.required]],
      CAddr:['',[Validators.required]],
      email:['',[Validators.required]],
      telephone:['',[Validators.required]],
      fax:['',[Validators.required]],
      holding:['',Validators.required],
      auth_person:['',[Validators.required]],
      designation:['',[Validators.required]],
      gst_no:['',[Validators.required]],
      pan_no:['',[Validators.required]],
      username:['',[Validators.required]],
      password:['',[Validators.required]],
    
    });

  }

  get name()
  {
    return this.regForm.get('c_name');
  }

  get addr()
  {
    return this.regForm.get('c_addr');
  }
  get email()
  {
    return this.regForm.get('email');
  }

  get telephone()
  {
    return this.regForm.get('telephone');
  }

  get fax()
  {
    return this.regForm.get('fax');
  }

  get holding()
  {
    return this.regForm.get('holding');
  }

  get auth_person()
  {
    return this.regForm.get('auth_person');
  }

  get designation()
  {
    return this.regForm.get('designation');
  }

  get gst_no()
  {
    return this.regForm.get('gst_no');
  }

  get pan_no()
  {
    return this.regForm.get('pan_no');
  }

  get username()
  {
    return this.regForm.get('username');
  }
  get password()
  {
    return this.regForm.get('password');
  }


  onSubmit(empForm:FormGroup)
  {
    this.submited=true;
    if(!empForm.valid)
    {
      console.log(empForm.value)
    }

    this.mapFormValues(empForm);
    this.postData(this.regObj);
  }


  mapFormValues(form:FormGroup)
  {
    this.regObj=new Customers(null, '', '', '', '', '', '', '', '', '', '','','');
    this.regObj.CName=form.controls.CName.value;
    this.regObj.CAddr=form.controls.CAddr.value;
    this.regObj.email=form.controls.email.value;
    this.regObj.telephone=form.controls.telephone.value;
    this.regObj.fax=form.controls.fax.value;
    this.regObj.holding=form.controls.holding.value;
    this.regObj.designation=form.controls.designation.value;
    this.regObj.authPerson=form.controls.auth_person.value;
    this.regObj.gstNo=form.controls.gst_no.value;
    this.regObj.panNo=form.controls.pan_no.value;
    this.regObj.username=form.controls.username.value;
    this.regObj.password=form.controls.password.value;
  }
  
  postData(CusObj)
  {
   //this.dataserv.postcustomer(CusObj).subscribe((data)) =>{console.log(data );this.router.navigate(['/home']);});
   this.dataserv.postcustomer(CusObj).subscribe(data=>{console.log(data );this.router.navigate(['/home']);});
  }
}
