import { Component, OnInit } from '@angular/core';
import { RegService } from '../reg.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  errorMsg : string;
  constructor(private regService : RegService) {
    
  }

  ngOnInit() {
  }

  logout()
  {
    localStorage.clear();
    // this.regService.invalidate().subscribe();
  }


}
