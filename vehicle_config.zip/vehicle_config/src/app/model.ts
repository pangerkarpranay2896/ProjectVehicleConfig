import { Modeldetail } from './modeldetail';
import { Alttbl } from './alttbl';
import { Imodel } from './imodel';

export class Model implements Imodel {
    constructor(public id : number, public manufacturer: number, public segments : number,
        public modelName : string, public modelDescip : string, public modelImg : string, 
        public mfgDate : string, public price : number, public altTbls : Set<Alttbl>,
        public modelDetails : Set<Modeldetail>){}
}
