import { Model } from './model';

export interface Imanufacturer {
    id : number;
	manuName : string;
	modelses : Set<Model>;
}

