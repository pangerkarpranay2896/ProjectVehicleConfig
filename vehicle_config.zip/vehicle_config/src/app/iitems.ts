import { Alttbl } from './alttbl';
import { Modeldetail } from './modeldetail';

export interface Iitems {
    id : number;
	name : string;
	modelDetails : Set<Modeldetail>;
	altTbls : Set<Alttbl>;
}

