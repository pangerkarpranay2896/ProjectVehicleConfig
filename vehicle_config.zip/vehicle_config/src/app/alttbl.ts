export class Alttbl {
}
