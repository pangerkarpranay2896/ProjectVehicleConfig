package customers;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pojopack.Customers;

@Repository
@Transactional
public class CustomerDAOImpl implements CustomerDAO{

	@Autowired
	HibernateTemplate template;
	
	
	public void addCustomers(Customers p) {
		template.save(p);
	}

	@Override
	public List<Customers> getCustomers() {
		
		List<Customers> list = (List<Customers>)template.find("from Customers");
		return list;
	}

	@Override
	public void delete(int id) {
		template.delete(template.get(Customers.class,id));
	}

	@Override
	public void update(Customers customer, int id) {
		
	}

	@Override
	public Customers fetchSingleCustomer(int id) {
		Customers customer = (Customers)template.find("from Customers c where c.id =?", id).get(0);
		//Product temp=(Product)template.find("from Product p where p.id=?",id).get(0);
		return customer;
	}

}
