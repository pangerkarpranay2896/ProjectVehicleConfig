package customers;

import java.util.List;

import pojopack.Customers;

public interface CustomerDAO {
	
	void addCustomers(Customers p);
	List<Customers> getCustomers();
	void delete(int id);
	void update(Customers customer,int id);
	Customers fetchSingleCustomer(int id);
	
}
