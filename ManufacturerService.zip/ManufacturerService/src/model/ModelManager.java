package model;

import java.util.List;

import pojopack.Models;


public interface ModelManager {
	List<Models> getMod();
	void addMod(Models manufacturer);
	void deleteMod(int id);
	List<Models> getModList(int s_id,int manufacturer_id);
}
