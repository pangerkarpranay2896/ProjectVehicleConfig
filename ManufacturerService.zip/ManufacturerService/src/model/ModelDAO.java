package model;

import java.util.List;

import pojopack.Models;

public interface ModelDAO {

	List<Models> getList();
	void addModels(Models manufacturer);
	void deleteModels(int id);
	List<Models> getModelLists(int seg_id, int manufacturer_ids);
	
}
