package model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import pojopack.Models;

@RestController
@CrossOrigin("http://localhost:4200")
public class ModelController {

	@Autowired
	ModelManager manager;
	
	@GetMapping(value="crud/models", headers="Accept=application/json")
	public String getManufacturers()
	{
		return new Gson().toJson(manager.getMod());
	}
	
	@PostMapping(value="crud/addModel", headers="Accept=application/json")
	public void addManufacturer(@RequestBody Models model)
	{
		manager.addMod(model);
	}
	
	@DeleteMapping(value="crud/deleteModel/{id}", headers="Accept=application/json")
	public void delManufacturer(@PathVariable int id)
	{
		manager.deleteMod(id);
	}
	
	@GetMapping(value="crud/getModelBySegment/{segment_id}/{manufacturer_id}", headers="Accept=application/json")
	public String getManufacturerBySegmentManufacturer(@PathVariable int segment_id, @PathVariable int manufacturer_id)
	{
		return new Gson().toJson(manager.getModList(segment_id,manufacturer_id));
	}
	
}
