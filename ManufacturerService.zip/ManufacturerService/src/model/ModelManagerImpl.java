package model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pojopack.Models;

@Service
public class ModelManagerImpl implements ModelManager {

	@Autowired
	ModelDAO mdao;
	
	@Override
	public List<Models> getMod() {
		return mdao.getList();
	}

	@Override
	public void addMod(Models manufacturer) {
		mdao.addModels(manufacturer);
	}

	@Override
	public void deleteMod(int id) {
		mdao.deleteModels(id);
	}

	@Override
	public List<Models> getModList(int seg_id, int manufacturer_id) {
		return mdao.getModelLists(seg_id, manufacturer_id);
	}

}
