package manufacturers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pojopack.Manufacturer;

@Service
public class ManufacturerManagerImpl implements ManufacturerManager {

	@Autowired
	ManufacturerDAO mdao;
	
	@Override
	public List<Manufacturer> getMan() {
		List<Manufacturer> list = mdao.getList();
		return list;
	}

	@Override
	public void addMan(Manufacturer manufacturer) {
		mdao.addManufacturer(manufacturer);
	}

	@Override
	public void deleteMan(int id) {
		mdao.deleteManufacturer(id);
	}

	public List<Manufacturer> getManList(int seg_id) {
		return mdao.getManLists(seg_id);
	}
	
	
}
