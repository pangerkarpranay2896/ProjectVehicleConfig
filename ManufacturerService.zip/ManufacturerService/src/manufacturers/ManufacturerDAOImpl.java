package manufacturers;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pojopack.Manufacturer;


@Repository
@Transactional
public class ManufacturerDAOImpl implements ManufacturerDAO{

	@Autowired
	HibernateTemplate template;
	
	@Override
	public List<Manufacturer> getList() {

		@SuppressWarnings("unchecked")
		List<Manufacturer> list = (List<Manufacturer>)template.find("from Manufacturer");
		return list;
	}

	@Override
	public void addManufacturer(Manufacturer manufacturer) {
		template.save(manufacturer);
	}

	@Override
	public void deleteManufacturer(int id) {
		template.delete(template.get(Manufacturer.class, id));
	}
	
	public List<Manufacturer> getManLists(int seg_id) {
		
		Session session = template.getSessionFactory().getCurrentSession();
		
		
		@SuppressWarnings({ "deprecation", "rawtypes" })
		Query query = session.createSQLQuery(
				"CALL get_manufacturer(:int_seg_id)").addEntity(Manufacturer.class)
				.setParameter("int_seg_id", seg_id);
		
		@SuppressWarnings({ "deprecation", "unchecked" })
		List<Manufacturer> list = query.list();
		return list;
	}

}
