package segment;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pojopack.Segments;

@Service
public class SengmentsManagerImpl implements SengmentsManager {
	@Autowired
	SegmentsDAO sdao;

	@Override
	public void addSegment(Segments s) {
		sdao.addSegment(s);
		
	}

	@Override
	public List<Segments> getSegments() {
		List<Segments> list = sdao.getSegments();
		return list;
		
	}

	

}
