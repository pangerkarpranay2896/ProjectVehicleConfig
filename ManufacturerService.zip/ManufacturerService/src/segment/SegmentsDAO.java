package segment;

import java.util.List;

import pojopack.Segments;

public interface SegmentsDAO {
	void addSegment(Segments s);
	List<Segments> getSegments();
	//void delete(int id);
	//void update(Segments seg,int id);
	//Segments fetchSingleSegments(int id);

}
