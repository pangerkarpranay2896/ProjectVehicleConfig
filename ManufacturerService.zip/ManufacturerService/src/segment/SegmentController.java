package segment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import pojopack.Segments;

@RestController
@CrossOrigin("http://localhost:4200")
public class SegmentController {
	@Autowired
	SengmentsManager sman;
	
	@GetMapping(value="crud/segments", headers="Accept=application/json")
	public String getSegments ()
	{
		return new Gson().toJson(sman.getSegments());
	}
	
	@PostMapping(value="crud/addSegment", headers="Accept=application/json")
	public void addSegment(@RequestBody Segments seg)
	{
		sman.addSegment(seg);
	}
	

}
