package segment;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pojopack.Segments;

@Repository
@Transactional
public class SegmentsDaoImpl implements SegmentsDAO {
	@Autowired
	HibernateTemplate template;

	@Override
	public void addSegment(Segments s) {
		template.save(s);
		
	}

	@Override
	public List<Segments> getSegments() {
		List<Segments> list = (List<Segments>) template.find("from Segments");
		return list;
	}

	
}
