package productDetails;

import java.util.List;

import pojopack.Items;

public interface ProductDetailManager {

	List<Items>	getDefaultDetails(int id);
	List<Items>	getDetails(int id, String configType);
	
}
