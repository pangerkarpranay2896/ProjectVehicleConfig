package productDetails;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pojopack.Items;

@Service
public class ProductDetailManagerImpl implements ProductDetailManager{

	@Autowired
	ProductDetailDAO pdao;

	@Override
	public List<Items> getDefaultDetails(int id) {
		return pdao.getDefaultDetails(id);
	}

	@Override
	public List<Items> getDetails(int id, String configType) {
		return pdao.getDetails(id, configType);
	}
	
	
	

}
