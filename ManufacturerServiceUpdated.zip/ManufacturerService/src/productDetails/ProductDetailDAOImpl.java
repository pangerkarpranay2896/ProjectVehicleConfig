package productDetails;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pojopack.Items;

@Repository
@Transactional
public class ProductDetailDAOImpl implements ProductDetailDAO{

	@Autowired
	HibernateTemplate template;
	

	@Override
	public List<Items> getDefaultDetails(int id) {
		Session session = template.getSessionFactory().openSession();
		@SuppressWarnings({ "deprecation", "rawtypes" })
		Query query = session.createSQLQuery("CALL getDefaultItemDetails(:int_model_id)")
										.addEntity(Items.class).setParameter("int_model_id", id);
		@SuppressWarnings({ "deprecation", "rawtypes" })
		List<Items> list = query.list();
		return list;
	}


	@Override
	public List<Items> getDetails(int id, String configType) {
		Session session = template.getSessionFactory().openSession();
		@SuppressWarnings({ "deprecation", "rawtypes" })
		Query query = session.createSQLQuery("CALL getItemDetails(:int_model_id, :string_model_type)")
										.addEntity(Items.class)
										.setParameter("int_model_id", id)
										.setParameter("string_model_type", configType);
		@SuppressWarnings({ "deprecation", "rawtypes" })
		List<Items> list = query.list();	
		return list;
	}

}
