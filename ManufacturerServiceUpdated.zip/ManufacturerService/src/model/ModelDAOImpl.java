package model;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pojopack.Models;


@Repository
@Transactional
public class ModelDAOImpl implements ModelDAO{

	@Autowired
	HibernateTemplate template;
	
	@Override
	public List<Models> getList() {
		List<Models> list = (List<Models>) template.find("from Models");
		return list;
	}

	@Override
	public void addModels(Models manufacturer) {
		template.save(manufacturer);
	}

	@Override
	public void deleteModels(int id) {
		System.out.println(id);
		template.delete(template.get(Models.class,id));
	}

	@Override
	public List<Models> getModelLists(int segment_id, int manufacturer_id) {
		
Session session = template.getSessionFactory().getCurrentSession();
		
		@SuppressWarnings({ "deprecation", "rawtypes" })
		Query query = session.createSQLQuery(
				"CALL get_models(:int_seg_id,:int_man_id)").addEntity(Models.class)
				.setParameter("int_seg_id", segment_id).setParameter("int_man_id",manufacturer_id );
		
		@SuppressWarnings({ "deprecation", "unchecked" })
		List<Models> list = query.list();
		return list;
	}

	@Override
	public Models getModelById(int id) {
		Models model = (Models)template.find("from Models m where m.id=?", id).get(0);
		return model;
	}

	
	
}
