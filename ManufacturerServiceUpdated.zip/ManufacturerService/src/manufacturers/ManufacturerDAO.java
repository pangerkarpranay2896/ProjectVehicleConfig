package manufacturers;
import java.util.List;

import pojopack.*;
public interface ManufacturerDAO {

	List<Manufacturer> getList();
	void addManufacturer(Manufacturer manufacturer);
	void deleteManufacturer(int id);
	List<Manufacturer> getManLists(int seg_id);
}
