package pojopack;

import java.math.BigDecimal;

import javax.persistence.Entity;

import org.springframework.stereotype.Component;

@Entity
public class AlternateTablePojo {

	private Integer id;
	private BigDecimal deltaPrice;
	private String name;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public BigDecimal getDeltaPrice() {
		return deltaPrice;
	}
	public void setDeltaPrice(BigDecimal deltaPrice) {
		this.deltaPrice = deltaPrice;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
