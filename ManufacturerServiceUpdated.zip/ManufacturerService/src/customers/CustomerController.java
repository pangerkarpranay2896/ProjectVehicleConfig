package customers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import pojopack.Customers;

@RestController
@CrossOrigin("http://localhost:4200")
public class CustomerController {
	
	@Autowired
	CustomerManager manager;
	
	@GetMapping(value="crud/customers", headers="Accept=application/json")
	public String getCustomers()
	{
		return new Gson().toJson(manager.getCustomers());
	}
	@GetMapping(value="api/singlecustomer/{id}", headers="Accept=application/json")
	public String retValue(@PathVariable int id)
	{
		System.out.println(id);
		Customers c = manager.getSingleCust(id);
		return new Gson().toJson(c);
	}
	
	@GetMapping(value="crud/loginedOrNot", headers="Accept=application/json")
	public String islogined(HttpServletRequest request )
	{
		HttpSession session = request.getSession(false);
		System.out.println(session.getAttribute("sessionAttr"));
		if(session == null)
		{
			return new Gson().toJson("false");
		}
		else
		{
			return new Gson().toJson("true");
		}
	}
	
	@GetMapping(value="crud/logout", headers="Accept=application/json")
	public void islogout(HttpServletRequest request )
	{
		HttpSession session = request.getSession(false);
		System.out.println(session.getAttribute("sessionAttr"));
		if(session != null)
		{
			session.invalidate();
		}
		System.out.println("LOGOUT");
		return ;
		
	}
	
	@PostMapping(value="crud/addCustomer", headers="Accept=application/json")
	public void addCustomers(@RequestBody Customers customer)
	{
		manager.addCustomer(customer);
	}
		
	
	@DeleteMapping(value="crud/deleteCustomer/{id}", headers="Accept=application/json")
	public void remove(@PathVariable int id)
	{
		manager.delete(id);
	}
	
	@PostMapping(value="crud/login", headers="Accept=application/json")
	public String login(@RequestBody Customers customer,HttpServletRequest request)
	{
		List<Customers> cuslist= manager.getCustomers();
		String bool="";
		HttpSession session = null ;
		for(Customers cust: cuslist)
		{
		
			if((cust.getUsername().equals(customer.getUsername())) && (cust.getPassword().equals(customer.getPassword())) )
			{
				bool = "true";
				session = request.getSession();
				//System.out.println(cust.getUsername());
				session.setAttribute("sessionAttr", cust.getUsername());
				//System.out.println();
				break;
			}
			else
			{
				bool = "false";
			}
		}
		return new Gson().toJson(bool);
	}
	
	
	
	
	
	
	
	
	
}
