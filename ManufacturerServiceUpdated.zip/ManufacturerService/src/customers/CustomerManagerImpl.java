package customers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pojopack.Customers;

@Service
public class CustomerManagerImpl implements CustomerManager{

	@Autowired
	CustomerDAO cdao;
	
	@Override
	public void addCustomer(Customers p) {
		cdao.addCustomers(p);
	}

	@Override
	public List<Customers> getCustomers() {
		List<Customers> list = cdao.getCustomers();
		return list;
	}

	@Override
	public void delete(int id) {
		cdao.delete(id);
	}

	@Override
	public void update(Customers product, int id) {
		
	}

	@Override
	public Customers getSingleCust(int id) {
		Customers customer = cdao.fetchSingleCustomer(id);
		return customer;
	}

}
