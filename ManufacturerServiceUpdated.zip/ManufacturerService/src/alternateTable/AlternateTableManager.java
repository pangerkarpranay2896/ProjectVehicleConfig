package alternateTable;

import java.util.List;

import pojopack.AlternateTablePojo;
import pojopack.ModelDetail;

public interface AlternateTableManager {

	List<ModelDetail> getModelDetailsByModelId(int id, String model_type);
	
	List<AlternateTablePojo> getAlternateItems(int model_id);
	
	String getPrice(int id);
	
	String getPriceDemo(int alt_id , int model_id);
	
}
