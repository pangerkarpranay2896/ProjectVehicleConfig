package alternateTable;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;


@RestController
@CrossOrigin("http://localhost:4200")
public class AlternateTableController {

	@Autowired
	AlternateTableManager manager;
	
	@GetMapping(value="crud/getModelDetailsByModelId/{id}/{model_type}", headers="Accept=application/json")
	public String getModelDetailsByModelId(@PathVariable int id, @PathVariable String model_type) {
		return new Gson().toJson(manager.getModelDetailsByModelId(id, model_type));
	}
	
	@GetMapping(value="crud/getAlternateItems/{item_id}", headers="Accept=application/json")
	public String getAlternateItems(@PathVariable int item_id) {
		
		return new Gson().toJson(manager.getAlternateItems(item_id));
	}
	
	@GetMapping(value="crud/getPrice/{alt_table_id}", headers="Accept=application/json")
	public String getPrice(@PathVariable int alt_table_id) {
		
		return new Gson().toJson(manager.getPrice(alt_table_id));
	}
	
	
	@GetMapping(value="crud/getPriceDemo/{alt_table_id}/{model_id}", headers="Accept=application/json")
	public String getPriceDemo(@PathVariable int alt_table_id, @PathVariable int model_id)
	{
		return new Gson().toJson(manager.getPriceDemo(alt_table_id,model_id));
	}
	
	
	
}
