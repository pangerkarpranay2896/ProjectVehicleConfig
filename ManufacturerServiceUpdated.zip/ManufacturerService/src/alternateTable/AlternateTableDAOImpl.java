package alternateTable;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pojopack.AltTbl;
import pojopack.AlternateTablePojo;
import pojopack.Items;
import pojopack.ModelDetail;


@Repository
@Transactional
public class AlternateTableDAOImpl implements AlternateTableDAO{

	@Autowired
	HibernateTemplate template;
	
	@Override
	public List<ModelDetail> getModelDetailsByModelId(int id, String model_type) {
		
		@SuppressWarnings("unchecked")
//		List<ModelDetail> list = (List<ModelDetail>) template.
//				find("from ModelDetail m where m.model_id = ? and m.model_config = ? and m.model_type=?",
//						id, "Y", model_type);
		Session session = template.getSessionFactory().getCurrentSession();
		Query query = session.createSQLQuery("SELECT * FROM model_detail where model_id = :mid AND model_config = 'Y' AND model_type = :mtype")
				.addEntity(ModelDetail.class).setParameter("mid", id).setParameter("mtype", model_type);
		
		List<ModelDetail> list = query.list();
		return list;
	}

	@Override
	public List<AlternateTablePojo> getAlternateItems(int model_id) {
		Session session = template.getSessionFactory().getCurrentSession();
		Query query = session.createSQLQuery("CALL getAlternateTableItem(:int_model_id)")
				.addEntity(Items.class).setParameter("int_model_id", model_id);
		
		List<AlternateTablePojo> list = query.list();
		return list;
	}

	@Override
	public String getPrice(int id) {
		Session session = template.getSessionFactory().getCurrentSession();
		Query query = session.createSQLQuery("SELECT * FROM alt_tbl WHERE alt_id = :altId")
				.addEntity(AltTbl.class).setParameter("altId", id);
		AltTbl obj = (AltTbl) query.list().get(0);
		return obj.getDeltaPrice().toString();
	}

	@Override
	public String getPriceDemo(int alt_id, int model_id) {
		Session session = template.getSessionFactory().getCurrentSession();
		Query query = session.createSQLQuery("SELECT * FROM alt_tbl WHERE alt_id = :altId AND model_id = :modelId")
				.addEntity(AltTbl.class).setParameter("altId", alt_id).setParameter("modelId", model_id);
		AltTbl obj = (AltTbl) query.list().get(0);
		return obj.getDeltaPrice().toString();
	}

}
