package alternateTable;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pojopack.AlternateTablePojo;
import pojopack.ModelDetail;

@Service
public class AlternateTableManagerImpl implements AlternateTableManager{

	@Autowired
	AlternateTableDAO adao;
	
	@Override
	public List<ModelDetail> getModelDetailsByModelId(int id, String model_type) {
		return adao.getModelDetailsByModelId(id, model_type);
	}

	@Override
	public List<AlternateTablePojo> getAlternateItems(int model_id) {
		return adao.getAlternateItems(model_id);
	}

	@Override
	public String getPrice(int id) {
		return adao.getPrice(id);
	}

	@Override
	public String getPriceDemo(int alt_id, int model_id) {
		return adao.getPriceDemo(alt_id, model_id);
	}

}
